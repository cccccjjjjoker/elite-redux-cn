# Elite Redux 2.65.5.2b 中文版源码构建

此包包含汉化源码、配置、中文字库和构建脚本。

- 主源码基线 [`bd7acbdd`](https://github.com/Elite-Redux/eliteredux-source/commit/bd7acbdd355f3ee6fa0ac862add1f51933305b52)
- `proto` 配置上游基线 `050dc341f10a281c48c225d69e5662d559f315e8`
- 上游基于 [pret/pokeemerald](https://github.com/pret/pokeemerald)

## Windows 构建

1. 启动使用 WSL 2 的 Docker Desktop，确认 `docker version` 能显示 Linux Server。
2. 解压外层 ZIP。在解压目录打开 PowerShell，保留里面的 `.tar.gz`，由 Linux 容器解包。
3. 执行 `.\build.ps1 -Jobs 8`。首次需要下载工具链。脚本还会从固定的上游提交取回构建所需的 `data/pokemon_colosseum.mb`，并校验它的 SHA-256。
4. 完成后在 `build-results` 的时间戳目录查看 `pokeemerald_modern.gba`、构建日志和校验值。

若 Docker Hub 下载失败，可检查 Docker Desktop 代理。若镜像能拉取但构建仍在取令牌时失败，可在同一 PowerShell 会话设置 `HTTP_PROXY` 和 `HTTPS_PROXY` 后重试。

## 校验

编译结果预期为 32 MiB，SHA-256 如下，与仓库的中文 BPS 输出相同。

```text
63f5859049f57c604acce855b93ca3b066669eea3f0608789b5d978351c46046
```

源码构建无需提供玩家的 ROM。只想游玩可按 [项目 README](https://github.com/cccccjjjjoker/elite-redux-cn#下载与使用指南) 使用中文 BPS。

感谢 Elite Redux 和 pokeemerald 项目的贡献者、完成源码汉化工程的 Elite Redux 汉化组，以及提供源码汉化思路的贴吧网友 eeee5555。
